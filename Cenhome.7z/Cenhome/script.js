$(function () {

    var imgBefore = '/images/cen-logo.png'
    var imgAfter = '/images/cen-logo-white.png'

    $(document).scroll(function () {
        var $nav = $(".background-before");
        if($(this).scrollTop() > $nav.height()){
            $('.img-change').attr('src', imgBefore)
            $('#icon-change').attr('class', 'fa fa-arrow-circle-up fa-2x')
            $('#link-change').attr('href', '#top')
        }else{
            $('.img-change').attr('src', imgAfter)
            $('#icon-change').attr('class', 'fa fa-arrow-circle-down fa-2x')
            $('#link-change').attr('href', '#bot')
        }

        
        $nav.toggleClass('background-after', $(this).scrollTop() > $nav.height());
      });
  });